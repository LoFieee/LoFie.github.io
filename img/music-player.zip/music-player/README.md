# Music Player

A Pen created on CodePen.io. Original URL: [https://codepen.io/webFardin/pen/WNJZVmJ](https://codepen.io/webFardin/pen/WNJZVmJ).

A mini music player with some beautiful themes